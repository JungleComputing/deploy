#!/bin/bash
shift
shift
$*
